import pyrogram

print("Starting program...", end='\n')
app = pyrogram.Client("my_account", api_hash="a56422581dac30132583dec3f9cec83a", api_id=16788338)
print("Client inited.", end='\n')


def extractText(string: str):
    return string[string.index("\"") + 1: string.rindex("\"")]


@app.on_message(pyrogram.filters.command("spam", prefixes=".") & pyrogram.filters.me)
async def hello(client, message):
    try:
        print("Message received: %s" % message.text, end='\n')
        count = int(message.text.split(" ")[1])
        message_text = extractText(message.text)
        for i in range(count):
            await message.reply(message_text)
    except Exception as e:
        await message.reply(e)


app.run()
